let myHeading = document.querySelector("h1");
myHeading.textContent = "关于我们";

